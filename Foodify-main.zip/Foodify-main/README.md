# Foodify
This is the first website created by me using HTML and CSS basics.

Below are the screeshots for better view-->
![1](https://github.com/DinanathDash/Foodify/assets/108653031/7420ffb7-cfa7-485d-8273-d39483c1baad)
![2](https://github.com/DinanathDash/Foodify/assets/108653031/eb7eef69-c8b9-4052-810e-7b32515039f2)
![3](https://github.com/DinanathDash/Foodify/assets/108653031/b26d9fa1-97a3-423c-a94a-4df851eb4f2d)
